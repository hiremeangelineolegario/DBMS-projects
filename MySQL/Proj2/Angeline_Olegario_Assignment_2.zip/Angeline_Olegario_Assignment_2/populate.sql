/* DEPARTMENT TABLE */

INSERT INTO department(name)
	VALUES 
	('Accounting'),
	('Maintenance'),
	('Development');

/* EMPLOYEE TABLE */

INSERT INTO employee(name, email, phonenumber)
	VALUES 
	('Deneen Willmon', 'deneen.willmon@gmail.com', '0908 787 8889'),
	('Lashay Dann', 'lashay.dann@gmail.com', '0908 787 8889'),
	('Kallie Jolliff', 'kallie@ymail.com', '0917 128 7291'),
	('Starla Priebe', 'starlap@yahoo.com', '0650 338 2292'),
	('Jannette Basnight', 'jannette012@hotmail.com', '0778 490 2817');

/* WORKSFORDEP TABLE */

INSERT INTO worksfordep("employeeName", "departmentName", role)
	VALUES 
	( (SELECT name from employee WHERE name='Deneen Willmon'),   (SELECT name from department WHERE name='Maintenance'), 'engineer') ,
    ( (SELECT name from employee WHERE name='Kallie Jolliff'),   (SELECT name from department WHERE name='Maintenance'), 'technician') ,
    ( (SELECT name from employee WHERE name='Starla Priebe'),   (SELECT name from department WHERE name='Development'), 'coder') ,
    ( (SELECT name from employee WHERE name='Lashay Dann'),   (SELECT name from department WHERE name='Accounting'), 'head accountant') ,
    ( (SELECT name from employee WHERE name='Jannette Basnight'), (SELECT name from department WHERE name='Development'), NULL);

/* MANAGES TABLE */

INSERT INTO manages("managerName", "subordinateName")
	VALUES ((SELECT name from employee WHERE name='Deneen Willmon'), (SELECT name from employee WHERE name='Kallie Jolliff')),
	((SELECT name from employee WHERE name='Deneen Willmon'), (SELECT name from employee WHERE name='Starla Priebe'));