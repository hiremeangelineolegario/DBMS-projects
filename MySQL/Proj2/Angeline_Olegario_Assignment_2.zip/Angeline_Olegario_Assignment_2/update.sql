-- (a) The manages table is now called isManagedBy

ALTER TABLE manages
RENAME TO isManagedBy;

-- (b) Deneed has married (congrats!) and has taken a new name: Crawley
UPDATE employee
SET name = 'Deneen Crawley'
WHERE name = 'Deneen Willmon';


/* (c) People will soon be quitting the firm or retiring so we want to add one piece
of information per employee: whether they are a current employee (true) or not 
(false). All employees are active for the moment.*/

ALTER TABLE employee
	ADD isActive BOOLEAN NOT NULL
	DEFAULT TRUE 


-- (d) Janette has retired

UPDATE employee
SET isActive = FALSE 
WHERE name = 'Jannette Basnight'
