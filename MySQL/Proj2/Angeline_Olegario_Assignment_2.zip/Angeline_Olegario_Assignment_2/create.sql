--> Tasks 1 and 2; Create Database

CREATE DATABASE "Assignment2"
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    CONNECTION LIMIT = -1;


--> Creating Task 2

 CREATE TABLE employee
(
    name text NOT NULL,
    email text,
    phonenumber text,
    PRIMARY KEY (name)
);

CREATE TABLE department
(
    name text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT department_pkey PRIMARY KEY (name)
);


CREATE TABLE worksfordep
(
    
    "employeeName" text NOT NULL,
    "departmentName" text NOT NULL,
    role text,
    PRIMARY KEY ("employeeName","departmentName"),
    CONSTRAINT "employeeName" FOREIGN KEY ("employeeName")
        REFERENCES public.employee (name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
        NOT VALID,
    CONSTRAINT "departmentName" FOREIGN KEY ("departmentName")
        REFERENCES public.department (name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
        NOT VALID
);


CREATE TABLE manages
(
    "managerName" text NOT NULL,
    "subordinateName" text NOT NULL,
    PRIMARY KEY ("managerName", "subordinateName"),
    CONSTRAINT "managerName" FOREIGN KEY ("managerName")
        REFERENCES public.employee (name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
        NOT VALID,
    CONSTRAINT "subordinateName" FOREIGN KEY ("subordinateName")
        REFERENCES public.employee (name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
        NOT VALID
);





