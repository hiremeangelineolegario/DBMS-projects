--a) List of employees & the department they work for

SELECT "employeeName", "departmentName" FROM worksfordep

--b) List of employees and their manager (show employees without manager)

SELECT employee.name, manages."managerName" FROM employee
LEFT JOIN manages ON employee.name = manages."subordinateName")

--c) List of employees having an 'a' in their name

SELECT name FROM employee
WHERE name LIKE '%a%'